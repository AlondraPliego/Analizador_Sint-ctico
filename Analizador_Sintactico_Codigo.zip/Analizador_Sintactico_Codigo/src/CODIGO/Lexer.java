/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CODIGO;

public class Lexer {
    private final String input;
    private int pos, linea, columna;
    private char currentChar;

    public Lexer(String input) {
        this.input = input;
        this.pos = this.columna = 0;
        this.linea = 1;
        this.currentChar = input.isEmpty() ? '\0' : input.charAt(0);
    }

    private void avanzar() {
        if (currentChar == '\n') {
            linea++;
            columna = 0;
        }
        pos++;
        columna++;
        currentChar = pos < input.length() ? input.charAt(pos) : '\0';
    }

    private void saltarEspacios() {
        while (currentChar != '\0' && Character.isWhitespace(currentChar)) {
            avanzar();
        }
    }

    private Token numero() {
        StringBuilder sb = new StringBuilder();
        int l = linea, c = columna;
        while (Character.isDigit(currentChar)) {
            sb.append(currentChar);
            avanzar();
        }
        return new Token(TokenType.NUMERO, sb.toString(), l, c);
    }

    private Token identificadorOAccionOMetodo() {
        StringBuilder sb = new StringBuilder();
        int l = linea, c = columna;
        while (Character.isLetterOrDigit(currentChar)) {
            sb.append(currentChar);
            avanzar();
        }
        String lex = sb.toString();
        switch (lex.toLowerCase()) {
            case "robot":
                return new Token(TokenType.PALABRA_R, lex, l, c);
            case "iniciar":
            case "finalizar":
                return new Token(TokenType.ACCION, lex, l, c);
            case "base":
            case "cuerpo":
            case "garra":
            case "velocidad":
                return new Token(TokenType.METODO, lex, l, c);
            default:
                return new Token(TokenType.IDENTIFICADOR, lex, l, c);
        }
    }

    public Token getSiguienteToken() {
        while (currentChar != '\0') {
            if (Character.isWhitespace(currentChar)) {
                saltarEspacios();
                continue;
            }
            if (Character.isLetter(currentChar)) {
                return identificadorOAccionOMetodo();
            }
            if (Character.isDigit(currentChar)) {
                return numero();
            }
            // símbolos simples:
            if (currentChar == '.') {
                Token t = new Token(TokenType.PUNTO, ".", linea, columna);
                avanzar();
                return t;
            }
            if (currentChar == '=') {
                Token t = new Token(TokenType.ASIGNACION, "=", linea, columna);
                avanzar();
                return t;
            }
            if (currentChar == ';') {
                Token t = new Token(TokenType.PUNTO_COMA, ";", linea, columna);
                avanzar();
                return t;
            }
            // cualquier otro carácter
            Token t = new Token(TokenType.NO_VALIDO,
                                String.valueOf(currentChar),
                                linea, columna);
            avanzar();
            return t;
        }
        return new Token(TokenType.EOF, "", linea, columna);
    }
}

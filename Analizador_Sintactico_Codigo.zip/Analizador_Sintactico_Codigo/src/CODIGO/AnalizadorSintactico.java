/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CODIGO;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashMap;
import java.util.Map;
/**
 *
 * @author julia
 */


public class AnalizadorSintactico {
    private final List<Token> tokens;
    private final List<SyntaxError> errors = new ArrayList<>();
    private int errorCount = 0;

    public AnalizadorSintactico(List<Token> tokens) {
        this.tokens = tokens;
    }

    public List<SyntaxError> getErrors() {
        return errors;
    }

    private void report(int linea, int columnaToken, String mensaje, String token) {
        errorCount++;
        errors.add(new SyntaxError(errorCount, linea, columnaToken, mensaje, token));
    }

    public void parse() {
        // 1) Agrupar tokens por línea
        Map<Integer, List<Token>> porLinea = new LinkedHashMap<>();
        for (Token tk : tokens) {
            if (tk.getTipo() == TokenType.EOF) break;
            porLinea
              .computeIfAbsent(tk.getLinea(), k -> new ArrayList<>())
              .add(tk);
        }

        // 2) Procesar cada línea de forma aislada
        for (Map.Entry<Integer, List<Token>> entry : porLinea.entrySet()) {
            int linea = entry.getKey();
            List<Token> lineaToks = entry.getValue();
            analizarLinea(linea, lineaToks);
        }
    }

    private void analizarLinea(int linea, List<Token> lt) {
        if (lt.isEmpty()) return;

        // Último token de la línea:
        Token ultimo = lt.get(lt.size() - 1);
        boolean tienePuntoYComa = ultimo.getTipo() == TokenType.PUNTO_COMA;
        int size = tienePuntoYComa ? lt.size() - 1 : lt.size();

        // Si falta el ';'
        if (!tienePuntoYComa) {
            report(
                linea,
                lt.size() + 1,
                "Token faltante: se esperaba ';' al final de la instrucción",
                ";"
            );
        }

        // 3) ¿Robot o Sentencia?
        Token primero = lt.get(0);
        if (primero.getTipo() == TokenType.PALABRA_R) {
            parseRobot(linea, lt, size);
        } else if (primero.getTipo() == TokenType.IDENTIFICADOR) {
            parseStatement(linea, lt, size);
        } else {
            report(
                linea,
                tokenPos(lt, primero),
                "Token inesperado al inicio: se esperaba 'Robot' o un identificador",
                primero.getValor()
            );
        }
    }

    private void parseRobot(int linea, List<Token> lt, int size) {
        // Gramática: Robot IDENTIFICADOR ;
        if (size < 2) {
            report(
                linea,
                lt.size() >= 1 ? tokenPos(lt, lt.get(0)) + 1 : 1,
                "Token faltante: se esperaba IDENTIFICADOR después de 'Robot'",
                "IDENTIFICADOR"
            );
            return;
        }
        Token id = lt.get(1);
        if (id.getTipo() != TokenType.IDENTIFICADOR) {
            report(
                linea,
                tokenPos(lt, id),
                "Token incorrecto: se esperaba IDENTIFICADOR después de 'Robot'",
                id.getValor()
            );
        }
    }

    private void parseStatement(int linea, List<Token> lt, int size) {
        // Necesitamos al menos: IDENT . X
        if (size < 3) {
            Token t = lt.get(0);
            report(
                linea,
                tokenPos(lt, t),
                "Instrucción demasiado corta: se esperaba '.' y luego ACCION o MÉTODO",
                t.getValor()
            );
            return;
        }

        Token id   = lt.get(0),
              dot  = lt.get(1),
              op   = lt.get(2);

        // 1) PUNTO
        if (dot.getTipo() != TokenType.PUNTO) {
            report(
                linea,
                tokenPos(lt, dot),
                "Token incorrecto: se esperaba '.' tras identificador",
                dot.getValor()
            );
            return;
        }

        // 2) ACCION?
        if (op.getTipo() == TokenType.ACCION) {
            if (size != 3) {
                Token extra = lt.get(3);
                report(
                    linea,
                    tokenPos(lt, extra),
                    "Token inesperado después de la acción: no debe haber nada antes de ';'",
                    extra.getValor()
                );
            }
            return;
        }

        // 3) MÉTODO = NUMERO
        if (op.getTipo() != TokenType.METODO) {
            report(
                linea,
                tokenPos(lt, op),
                "Token incorrecto: se esperaba ACCION o MÉTODO tras '.'",
                op.getValor()
            );
            return;
        }

        // Esperamos al menos: IDENT . MÉTODO = NUMERO
        if (size < 5) {
            report(
                linea,
                lt.size() + 1,
                "Tokens faltantes: se esperaba '=' y NUMERO tras el método",
                "= NUMERO"
            );
            return;
        }

        Token eq  = lt.get(3),
              num = lt.get(4);

        if (eq.getTipo() != TokenType.ASIGNACION) {
            report(
                linea,
                tokenPos(lt, eq),
                "Token incorrecto: se esperaba '=' tras el método",
                eq.getValor()
            );
        }
        if (num.getTipo() != TokenType.NUMERO) {
            report(
                linea,
                tokenPos(lt, num),
                "Token incorrecto: se esperaba NUMERO tras '='",
                num.getValor()
            );
        }

        // Cualquier otro token antes del ';' es extra
        if (size > 5) {
            Token extra = lt.get(5);
            report(
                linea,
                tokenPos(lt, extra),
                "Token inesperado: no debe haber nada tras el número antes de ';'",
                extra.getValor()
            );
        }
    }

    /** Devuelve la posición (1-based) de tk dentro de la lista lt */
    private int tokenPos(List<Token> lt, Token tk) {
        return lt.indexOf(tk) + 1;
    }
}
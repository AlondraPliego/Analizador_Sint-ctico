/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CODIGO;

public class SyntaxError {

    private final int numero;      // p.e. 1, 2, 3…
    private final int linea;
    private final int columna;
    private final String mensaje;
    private final String token;    // el lexema que falló

    public SyntaxError(int numero, int linea, int columna, String mensaje, String token) {
        this.numero = numero;
        this.linea = linea;
        this.columna = columna;
        this.mensaje = mensaje;
        this.token = token;
    }

    @Override
    public String toString() {
        return String.format(
                "Error %d:%n"
                + "  Línea: %d%n"
                + "  Columna: %d%n"
                + "  Mensaje: %s%n"
                + "  Token: '%s'%n",
                numero, linea, columna, mensaje, token
        );
    }
}

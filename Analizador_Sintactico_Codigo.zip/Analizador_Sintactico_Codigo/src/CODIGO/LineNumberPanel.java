/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CODIGO;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Element;

// Clase interna para la numeración de líneas
    class LineNumberPanel extends JPanel implements DocumentListener {
        private static final long serialVersionUID = 1L;
        private final javax.swing.JTextArea textArea;
        private final int MARGIN = 5;
        
        public LineNumberPanel(javax.swing.JTextArea textArea) {
            this.textArea = textArea;
            setBackground(new Color(230, 230, 230));
            setForeground(Color.GRAY);
            textArea.getDocument().addDocumentListener(this);
            setBorder(new EmptyBorder(0, MARGIN, 0, MARGIN));
            
            // Configurar el ancho inicial
            actualizarAnchoPanel();
        }
        
        private void actualizarAnchoPanel() {
            // Obtener métricas de la fuente
            FontMetrics fontMetrics = textArea.getFontMetrics(textArea.getFont());
            int anchoCaracter = fontMetrics.charWidth('0');
            
            // Calcular la cantidad de dígitos necesarios
            int conteoLineas = getConteoLineas();
            int digitos = Integer.toString(conteoLineas).length();
            
            // Establecer el ancho preferido del panel
            int anchoPanelNumeros = digitos * anchoCaracter + MARGIN * 2 + 5;
            setPreferredSize(new Dimension(anchoPanelNumeros, 10));
            revalidate();
            repaint();
        }
        
        private int getConteoLineas() {
            Element root = textArea.getDocument().getDefaultRootElement();
            return root.getElementCount();
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            // Obtener información sobre las métricas de la fuente y las líneas
            FontMetrics fontMetrics = textArea.getFontMetrics(textArea.getFont());
            int altoLinea = fontMetrics.getHeight();
            int conteoLineas = getConteoLineas();
            
            Rectangle clip = g.getClipBounds();
            int startOffSet = clip.y / altoLinea;
            int endLine = Math.min(startOffSet + clip.height / altoLinea + 1, conteoLineas);
            
            int digitWidth = 0;
            int maxDigitos = Integer.toString(conteoLineas).length();
            
            // Calcular posiciones y dibujar números
            for (int i = startOffSet + 1; i <= endLine; i++) {
                String lineNumber = Integer.toString(i);
                
                // Alinear los números a la derecha
                int digitos = lineNumber.length();
                int x = getWidth() - fontMetrics.stringWidth(lineNumber) - MARGIN;
                
                // Calcular la posición y para alinear con la línea de texto
                int y = (int) ((i - 0.6) * altoLinea + fontMetrics.getAscent());
                
                // Dibujar el número de línea
                g.setColor(getForeground());
                g.drawString(lineNumber, x, y);
            }
        }
        
        // Implementación de DocumentListener
        @Override
        public void insertUpdate(DocumentEvent e) {
            actualizarAnchoPanel();
        }
        
        @Override
        public void removeUpdate(DocumentEvent e) {
            actualizarAnchoPanel();
        }
        
        @Override
        public void changedUpdate(DocumentEvent e) {
            actualizarAnchoPanel();
        }
    }
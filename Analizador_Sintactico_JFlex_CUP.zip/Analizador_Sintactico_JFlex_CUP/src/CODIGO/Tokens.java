package CODIGO;

/**
 * Enumeración de los tokens léxicos
 * 
 * @author Hp (modificado)
 */
public enum Tokens {
    No_identificada,
    Reservadas, 
    Palabra_r,
    Identificador,
    Punto,
    Punto_Coma,
    Accion,
    Metodo,
    Igual,
    Numero
}
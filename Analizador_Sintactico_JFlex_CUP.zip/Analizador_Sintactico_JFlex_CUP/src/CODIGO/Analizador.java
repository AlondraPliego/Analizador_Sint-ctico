package CODIGO;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.table.TableCellRenderer;
import javax.swing.text.*;
import java_cup.runtime.Symbol;

public class Analizador {

    public static class TokenInfo {
        public final String lexema;
        public final String tipo;

        public TokenInfo(String lexema, String tipo) {
            this.lexema = lexema;
            this.tipo = tipo;
        }
    }

    // Para almacenar resultados del análisis sintáctico
    public static class ResultadoAnalisis {
        public final List<TokenInfo> tokens;
        public final List<Sintactico.ErrorSintactico> erroresSintacticos;
        public final boolean exitoso;

        public ResultadoAnalisis(List<TokenInfo> tokens, List<Sintactico.ErrorSintactico> erroresSintacticos) {
            this.tokens = tokens;
            this.erroresSintacticos = erroresSintacticos;
            this.exitoso = erroresSintacticos.isEmpty();
        }
    }

    public static ResultadoAnalisis analizarTextoCompleto(String texto) throws Exception {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El texto no puede estar vacío");
        }
        
        // Verificar que el texto termine con punto y coma
        String textoTrimmed = texto.trim();
        if (!textoTrimmed.endsWith(";")) {
            List<TokenInfo> tokens = new ArrayList<>();
            List<Sintactico.ErrorSintactico> errores = new ArrayList<>();
            errores.add(new Sintactico.ErrorSintactico(
                textoTrimmed.split("\n").length,
                textoTrimmed.length(),
                "Error: El programa debe terminar con punto y coma"
            ));
            return new ResultadoAnalisis(tokens, errores);
        }
        
        // 1. Análisis léxico
        List<TokenInfo> tokens = new ArrayList<>();
        
        // Crear un nuevo lexer
        Lexer lexer = new Lexer(new StringReader(texto));
        
        // Crear un nuevo parser y pasarle el lexer
        Sintactico parser = new Sintactico(lexer);
        parser.reset(); // Reiniciar el estado del parser
        
        try {
            parser.parse(); // Iniciar el análisis sintáctico
        } catch (Exception e) {
            // Si el error es por falta de punto y coma al final
            if (e.getMessage() != null && e.getMessage().contains("EOF")) {
                parser.addError(1, 1, "Error: El programa debe terminar con punto y coma");
            }
        }
        
        // Obtener los tokens para la tabla (segundo lexer para recorrer tokens)
        lexer = new Lexer(new StringReader(texto));
        Symbol s;
        while (true) {
            try {
                s = lexer.next_token();
                if (s.sym == 0) { // EOF
                    break;
                }
                
                String tipo = symToString(s.sym);
                String lexema = s.value != null ? s.value.toString() : "";
                
                tokens.add(new TokenInfo(lexema, tipo));
            } catch (Exception e) {
                break;
            }
        }
        
        return new ResultadoAnalisis(tokens, parser.getErrores());
    }
    
    // Convertir número de símbolo a string de tipo
    private static String symToString(int symbolValue) {
        switch (symbolValue) {
            case sym.Palabra_r: return "Palabra_r";
            case sym.Identificador: return "Identificador";
            case sym.Metodo: return "Método";
            case sym.Accion: return "Acción";
            case sym.Igual: return "Igual";
            case sym.Punto: return "Punto";
            case sym.Punto_Coma: return "Punto_Coma";
            case sym.Numero: return "Número";
            case sym.No_identificada: return "No válido";
            default: return "Desconocido";
        }
    }

    public static String generarReporte(ResultadoAnalisis resultado) {
        StringBuilder reporte = new StringBuilder();
        
        // Sección de análisis léxico
        reporte.append("=== ANÁLISIS LÉXICO ===\n\n");

        if (resultado.tokens.isEmpty()) {
            reporte.append("No se encontraron tokens válidos\n");
        } else {
            int anchoLexema = Math.max(
                    resultado.tokens.stream().mapToInt(t -> t.lexema.length()).max().orElse(0),
                    "LEXEMA".length()
            );
            int anchoTipo = Math.max(
                    resultado.tokens.stream().mapToInt(t -> t.tipo.length()).max().orElse(0),
                    "TIPO".length()
            );

            anchoLexema = Math.max(Math.min(anchoLexema, 25), 10);
            anchoTipo = Math.max(Math.min(anchoTipo, 25), 10);

            String formatoEncabezado = "%-" + anchoLexema + "s %-" + anchoTipo + "s%n";
            reporte.append(String.format(formatoEncabezado, "LEXEMA", "TIPO"));

            reporte.append(String.format("%-" + (anchoLexema + anchoTipo + 1) + "s%n",
                    "").replace(' ', '-'));

            String formatoFila = "%-" + anchoLexema + "s %-" + anchoTipo + "s%n";

            for (TokenInfo t : resultado.tokens) {
                String lexema = t.lexema.length() > anchoLexema
                        ? t.lexema.substring(0, anchoLexema - 3) + "..."
                        : t.lexema;

                String tipo = t.tipo.length() > anchoTipo
                        ? t.tipo.substring(0, anchoTipo - 3) + "..."
                        : t.tipo;

                reporte.append(String.format(formatoFila, lexema, tipo));
            }

            reporte.append("\nTotal tokens: ").append(resultado.tokens.size());
        }
        
        // Sección de análisis sintáctico
        reporte.append("\n\n=== ANÁLISIS SINTÁCTICO ===\n\n");
        
        if (resultado.exitoso) {
            reporte.append("Análisis sintáctico exitoso. No se encontraron errores.");
        } else {
            reporte.append("Se encontraron ").append(resultado.erroresSintacticos.size())
                    .append(" errores sintácticos:\n\n");
            
            for (Sintactico.ErrorSintactico error : resultado.erroresSintacticos) {
                reporte.append("Error en línea ").append(error.linea)
                        .append(", columna ").append(error.columna)
                        .append(": ").append(error.mensaje)
                        .append("\n");
            }
        }

        return reporte.toString();
    }

    static class TokenTableCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                                                     boolean isSelected, boolean hasFocus, 
                                                     int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (column == 1 && "No válido".equals(value)) {
                c.setForeground(Color.RED);
            } else {
                c.setForeground(Color.BLACK);
            }
            
            return c;
        }
    }

    static class HeaderRenderer implements TableCellRenderer {
        private final TableCellRenderer defaultRenderer;

        public HeaderRenderer(TableCellRenderer defaultRenderer) {
            this.defaultRenderer = defaultRenderer;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                                                     boolean isSelected, boolean hasFocus, 
                                                     int row, int column) {
            JLabel header = (JLabel) defaultRenderer.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);
            
            header.setBackground(new Color(0, 102, 153));
            header.setForeground(Color.WHITE);
            header.setHorizontalAlignment(SwingConstants.CENTER);
            header.setBorder(BorderFactory.createEtchedBorder());
            header.setFont(header.getFont().deriveFont(Font.BOLD));
            
            return header;
        }
    }

    public static void generarReporteEnPane(ResultadoAnalisis resultado, JTextPane textPane) {
        try {
            // Crear un documento enriquecido
            StyledDocument doc = new DefaultStyledDocument();
            textPane.setStyledDocument(doc);
            
            // Estilos para el texto
            Style estiloPredeterminado = textPane.addStyle("predeterminado", null);
            StyleConstants.setFontFamily(estiloPredeterminado, "Consolas");
            StyleConstants.setFontSize(estiloPredeterminado, 12);
            
            Style estiloTitulo = textPane.addStyle("titulo", estiloPredeterminado);
            StyleConstants.setBold(estiloTitulo, true);
            StyleConstants.setFontSize(estiloTitulo, 14);
            StyleConstants.setForeground(estiloTitulo, new Color(0, 102, 153));
            
            // Sección de análisis léxico - solo tokens
            doc.insertString(doc.getLength(), "=== ANÁLISIS LÉXICO ===\n\n", estiloTitulo);
            
            // Crear tabla de tokens
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            
            model.addColumn("LEXEMA");
            model.addColumn("TIPO");
            
            for (TokenInfo token : resultado.tokens) {
                model.addRow(new Object[]{token.lexema, token.tipo});
            }
            
            JTable table = new JTable(model);
            table.setRowHeight(25);
            table.setShowGrid(true);
            table.setGridColor(Color.LIGHT_GRAY);
            table.setRowSelectionAllowed(true);
            
            TokenTableCellRenderer cellRenderer = new TokenTableCellRenderer();
            cellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
            table.setDefaultRenderer(Object.class, cellRenderer);
            
            HeaderRenderer headerRenderer = new HeaderRenderer(table.getTableHeader().getDefaultRenderer());
            table.getTableHeader().setDefaultRenderer(headerRenderer);
            
            JLabel totalLabel = new JLabel("Total tokens: " + resultado.tokens.size(), SwingConstants.CENTER);
            totalLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
            totalLabel.setFont(new Font("Consolas", Font.BOLD, 14));
            totalLabel.setForeground(new Color(0, 102, 153));
            totalLabel.setOpaque(true);
            totalLabel.setBackground(new Color(240, 240, 240));
            
            JPanel tablaPanel = new JPanel(new BorderLayout(0, 0));
            tablaPanel.add(table.getTableHeader(), BorderLayout.NORTH);
            tablaPanel.add(table, BorderLayout.CENTER);
            tablaPanel.add(totalLabel, BorderLayout.SOUTH);
            
            // Añadir el panel de la tabla al textPane
            textPane.setCaretPosition(doc.getLength());
            textPane.insertComponent(tablaPanel);
            
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }
    
    // Nuevo método específico para mostrar los errores sintácticos
    public static void mostrarErroresEnPane(ResultadoAnalisis resultado, JTextPane textPane) {
    try {
        // Crear un documento enriquecido
        StyledDocument doc = new DefaultStyledDocument();
        textPane.setStyledDocument(doc);
        
        // Estilos para el texto
        Style estiloPredeterminado = textPane.addStyle("predeterminado", null);
        StyleConstants.setFontFamily(estiloPredeterminado, "Consolas");
        StyleConstants.setFontSize(estiloPredeterminado, 12);
        
        Style estiloTitulo = textPane.addStyle("titulo", estiloPredeterminado);
        StyleConstants.setBold(estiloTitulo, true);
        StyleConstants.setFontSize(estiloTitulo, 14);
        StyleConstants.setForeground(estiloTitulo, new Color(0, 102, 153));
        
        Style estiloError = textPane.addStyle("error", estiloPredeterminado);
        StyleConstants.setForeground(estiloError, Color.RED);
        StyleConstants.setBold(estiloError, true);
        
        Style estiloDetalleError = textPane.addStyle("detalleError", estiloPredeterminado);
        StyleConstants.setForeground(estiloDetalleError, new Color(153, 0, 0));
        
        Style estiloExito = textPane.addStyle("exito", estiloPredeterminado);
        StyleConstants.setForeground(estiloExito, new Color(0, 153, 0));
        StyleConstants.setBold(estiloExito, true);
        
        // Sección de análisis sintáctico
        doc.insertString(doc.getLength(), "=== ANÁLISIS SINTÁCTICO ===\n\n", estiloTitulo);
        
        if (resultado.exitoso) {
            doc.insertString(doc.getLength(), "Análisis sintáctico exitoso. No se encontraron errores.\n", estiloExito);
        } else {
            doc.insertString(doc.getLength(), "Se encontraron " + resultado.erroresSintacticos.size() + 
                    " errores sintácticos:\n\n", estiloError);
            
            int errorCount = 1;
            for (Sintactico.ErrorSintactico error : resultado.erroresSintacticos) {
                // Incluir número de error, línea y columna en formato destacado
                doc.insertString(doc.getLength(), 
                        "Error " + errorCount + ":\n", 
                        estiloError);
                
                doc.insertString(doc.getLength(), 
                        "  Línea: " + error.linea + "\n" +
                        "  Columna: " + error.columna + "\n" +
                        "  Mensaje: ", 
                        estiloDetalleError);
                
                doc.insertString(doc.getLength(), 
                        error.mensaje + "\n", 
                        estiloError);
                
                // Si hay un valor de token, también mostrarlo
                if (error.tokenValor != null && !error.tokenValor.isEmpty()) {
                    doc.insertString(doc.getLength(), 
                            "  Token: '" + error.tokenValor + "'\n", 
                            estiloDetalleError);
                }
                
                // Añadir espacio entre errores
                doc.insertString(doc.getLength(), "\n", estiloPredeterminado);
                
                errorCount++;
            }
        }
    } catch (BadLocationException e) {
        e.printStackTrace();
    }
    }
}
package CODIGO;

import jflex.Main;
import jflex.exceptions.SilentExit;
import java.io.File;

public class Principal {
    public static void main(String[] args) {
        String rutaProyecto = System.getProperty("user.dir");
        String rutaLexer = rutaProyecto + "/src/CODIGO/Lexico.flex";
        String rutaSintaxis = rutaProyecto + "/src/CODIGO/Sintaxis.cup";
        
        generarLexicoYSintaxis(rutaLexer, rutaSintaxis);
    }
    
    public static void generarLexicoYSintaxis(String rutaLexer, String rutaSintaxis) {
        try {
            String[] flexArgs = { rutaLexer };
            Main.generate(flexArgs);
            System.out.println("Archivo Lexico.flex procesado exitosamente");
            
            String[] cupArgs = { "-parser", "Sintactico", rutaSintaxis };
            java_cup.Main.main(cupArgs);
            System.out.println("Archivo Sintaxis.cup procesado exitosamente");
            
            // Mover los archivos generados a la carpeta CODIGO
            File sym = new File("sym.java");
            File sintactico = new File("Sintactico.java");
            
            if (sym.exists()) {
                sym.renameTo(new File("src/CODIGO/sym.java"));
            }
            
            if (sintactico.exists()) {
                sintactico.renameTo(new File("src/CODIGO/Sintactico.java"));
            }
            
        } catch (SilentExit e) {
            System.out.println("Error al procesar el archivo Lexico.flex: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al procesar el archivo Sintaxis.cup: " + e.getMessage());
        }
    }
}
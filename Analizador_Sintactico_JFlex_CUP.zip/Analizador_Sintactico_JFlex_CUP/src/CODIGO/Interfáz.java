/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CODIGO;

import java.awt.Font;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Element;
/**
 *
 * @author Hp
 */
public class Interfáz extends javax.swing.JFrame {

    public Interfáz() {
        initComponents();
        jTextPane1.setEditable(false);
        
        // Configurar la numeración de líneas para el JTextArea
        LineNumberPanel lineNumberPanel = new LineNumberPanel(jTextArea1);
        jScrollPane1.setRowHeaderView(lineNumberPanel);
        
    }
    
      // Clase interna para la numeración de líneas
    private class LineNumberPanel extends JPanel implements DocumentListener {
        private static final long serialVersionUID = 1L;
        private final javax.swing.JTextArea textArea;
        private final int MARGIN = 5;
        
        public LineNumberPanel(javax.swing.JTextArea textArea) {
            this.textArea = textArea;
            setBackground(new Color(230, 230, 230));
            setForeground(Color.GRAY);
            textArea.getDocument().addDocumentListener(this);
            setBorder(new EmptyBorder(0, MARGIN, 0, MARGIN));
            
            // Configurar el ancho inicial
            actualizarAnchoPanel();
        }
        
        private void actualizarAnchoPanel() {
            // Obtener métricas de la fuente
            FontMetrics fontMetrics = textArea.getFontMetrics(textArea.getFont());
            int anchoCaracter = fontMetrics.charWidth('0');
            
            // Calcular la cantidad de dígitos necesarios
            int conteoLineas = getConteoLineas();
            int digitos = Integer.toString(conteoLineas).length();
            
            // Establecer el ancho preferido del panel
            int anchoPanelNumeros = digitos * anchoCaracter + MARGIN * 2 + 5;
            setPreferredSize(new Dimension(anchoPanelNumeros, 10));
            revalidate();
            repaint();
        }
        
        private int getConteoLineas() {
            Element root = textArea.getDocument().getDefaultRootElement();
            return root.getElementCount();
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            // Obtener información sobre las métricas de la fuente y las líneas
            FontMetrics fontMetrics = textArea.getFontMetrics(textArea.getFont());
            int altoLinea = fontMetrics.getHeight();
            int conteoLineas = getConteoLineas();
            
            Rectangle clip = g.getClipBounds();
            int startOffSet = clip.y / altoLinea;
            int endLine = Math.min(startOffSet + clip.height / altoLinea + 1, conteoLineas);
            
            int digitWidth = 0;
            int maxDigitos = Integer.toString(conteoLineas).length();
            
            // Calcular posiciones y dibujar números
            for (int i = startOffSet + 1; i <= endLine; i++) {
                String lineNumber = Integer.toString(i);
                
                // Alinear los números a la derecha
                int digitos = lineNumber.length();
                int x = getWidth() - fontMetrics.stringWidth(lineNumber) - MARGIN;
                
                // Calcular la posición y para alinear con la línea de texto
                int y = (int) ((i - 0.6) * altoLinea + fontMetrics.getAscent());
                
                // Dibujar el número de línea
                g.setColor(getForeground());
                g.drawString(lineNumber, x, y);
            }
        }
        
        // Implementación de DocumentListener
        @Override
        public void insertUpdate(DocumentEvent e) {
            actualizarAnchoPanel();
        }
        
        @Override
        public void removeUpdate(DocumentEvent e) {
            actualizarAnchoPanel();
        }
        
        @Override
        public void changedUpdate(DocumentEvent e) {
            actualizarAnchoPanel();
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        abrirArchvBtn = new javax.swing.JButton();
        GuardarArchivBtn = new javax.swing.JButton();
        limpiarBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setBackground(new java.awt.Color(22, 96, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Analizar");
        jButton1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CODIGO/Portada2.png"))); // NOI18N

        jScrollPane3.setViewportView(jTextPane1);

        jScrollPane2.setViewportView(jTextPane2);

        abrirArchvBtn.setText("Abrir archivo");
        abrirArchvBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirArchvBtnActionPerformed(evt);
            }
        });

        GuardarArchivBtn.setText("Guardar archivo");
        GuardarArchivBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarArchivBtnActionPerformed(evt);
            }
        });

        limpiarBtn.setText("Limpiar");
        limpiarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(abrirArchvBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(99, 99, 99)
                        .addComponent(GuardarArchivBtn))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 295, Short.MAX_VALUE)
                    .addComponent(jScrollPane3)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(limpiarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(abrirArchvBtn)
                            .addComponent(GuardarArchivBtn)
                            .addComponent(jButton1)
                            .addComponent(limpiarBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1)))
                    .addComponent(jLabel3))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    try {
            // 1. Obtener texto actual
            String textoActual = jTextArea1.getText().trim();

            // 2. Analizar el texto actual
            Analizador.ResultadoAnalisis resultado = Analizador.analizarTextoCompleto(textoActual);

            // 3. Mostrar los tokens en el primer panel
            Analizador.generarReporteEnPane(resultado, jTextPane1);
            jTextPane1.setFont(new Font("Courier New", Font.PLAIN, 12));
            jTextPane1.setMargin(new Insets(5, 5, 5, 5));
            
            // 4. Mostrar los errores sintácticos en el segundo panel
            Analizador.mostrarErroresEnPane(resultado, jTextPane2);
            jTextPane2.setFont(new Font("Courier New", Font.PLAIN, 12));
            jTextPane2.setMargin(new Insets(5, 5, 5, 5));
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error en análisis:\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void limpiarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarBtnActionPerformed
        jTextArea1.setText("");
        jTextPane1.setText("");
        jTextPane2.setText("");
        JOptionPane.showMessageDialog(this, "Se han limpiado todos los campos.", "Limpieza Completada", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_limpiarBtnActionPerformed

    private void GuardarArchivBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarArchivBtnActionPerformed
      JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Código Fuente");
        
        // Configurar filtros para archivos de texto
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Archivos de Texto (*.txt)", "txt");
        fileChooser.setFileFilter(filter);
        
        // Mostrar diálogo de guardado
        int seleccion = fileChooser.showSaveDialog(this);
        
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            
            // Verificar si el archivo tiene extensión .txt, si no, agregarla
            if (!archivo.getName().toLowerCase().endsWith(".txt")) {
                archivo = new File(archivo.getAbsolutePath() + ".txt");
            }
            
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
                // Obtener el texto del TextArea
                String texto = jTextArea1.getText();
                
                // Escribir el texto al archivo
                writer.write(texto);
                
                // Mensaje de confirmación
                JOptionPane.showMessageDialog(this, 
                        "Archivo guardado correctamente: " + archivo.getName(),
                        "Archivo Guardado", 
                        JOptionPane.INFORMATION_MESSAGE);
                
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error al guardar el archivo:\n" + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_GuardarArchivBtnActionPerformed

    private void abrirArchvBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirArchvBtnActionPerformed
                JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Abrir Código Fuente");
        // Configurar filtros para archivos de texto y código fuente comunes
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Archivos de Texto y Código", "txt", "java", "c", "cpp", "py", "html", "js", "css");
        fileChooser.setFileFilter(filter);
        
        // Mostrar diálogo de selección de archivo
        int seleccion = fileChooser.showOpenDialog(this);
        
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                StringBuilder contenido = new StringBuilder();
                String linea;
                
                // Leer el archivo línea por línea
                while ((linea = reader.readLine()) != null) {
                    contenido.append(linea).append("\n");
                }
                
                // Establecer el contenido en el TextArea
                jTextArea1.setText(contenido.toString());
                
                // Mensaje de confirmación
                JOptionPane.showMessageDialog(this, 
                        "Archivo abierto correctamente: " + archivo.getName(),
                        "Archivo Abierto", 
                        JOptionPane.INFORMATION_MESSAGE);
                
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error al abrir el archivo:\n" + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_abrirArchvBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfáz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfáz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfáz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfáz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfáz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton GuardarArchivBtn;
    private javax.swing.JButton abrirArchvBtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane2;
    private javax.swing.JButton limpiarBtn;
    // End of variables declaration//GEN-END:variables
}
